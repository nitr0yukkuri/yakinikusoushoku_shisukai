import { NativeTabs } from 'expo-router/unstable-native-tabs';
import { useColorScheme } from 'react-native';

import { Colors } from '@/constants/theme';

export default function AppTabs() {
  const scheme = useColorScheme();
  const colors = Colors[scheme === 'dark' ? 'dark' : 'light'];

  return (
    <NativeTabs
      backgroundColor={colors.background}
      indicatorColor={colors.backgroundElement}
      labelStyle={{ selected: { color: colors.text } }}>
      <NativeTabs.Trigger
        name="index"
        options={{
          title: 'Home',
          icon: require('@/assets/images/tabIcons/home.png'),
        }}
      />

      <NativeTabs.Trigger
        name="explore"
        options={{
          title: 'Explore',
          icon: require('@/assets/images/tabIcons/explore.png'),
        }}
      />
    </NativeTabs>
  );
}
