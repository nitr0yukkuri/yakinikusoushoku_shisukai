# 待つん屋

> "待つ側"に寄り添う待ち合わせアプリ

**作成日：** 2026年5月22日  
**チーム：** 焼肉草食

---

## 概要

相手の到着予定時間や近辺の暇つぶしスポットを表示し、待つ側のストレスを低減するアプリ。

---

## 背景・現状分析

遅刻者を待っている時間にイライラする人が多い。

- 待つ側のストレスにフォーカスを当てているシステムが少ない
- → 待たされている側のストレスを和らげるアプローチも少ない

---

## 何故イライラするのか

- 連絡がないと相手がどこにいるのか、いつ着くのかがわからずイライラする
- 待つことしか出来ないため暇になる（時間を奪われている気になる）
- 遅刻者の到着前に行動すると連携が取りづらく合流が面倒
- 終わりが分からない待ち時間はストレスが大きい

---

## 解決策

- 待ち合わせ時間に集合できない場合、相手の位置情報や到着予定時間を監視できるようにする
- 待っている側の位置情報も公開することで、先に行動していても合流しやすくする
- 待っている人に近辺の暇つぶしスポットを提案する
- 余裕を持たせて到着時間を表示することで、到着時間を超過してしまわないようにする

---

## 他のアプリとの差別化

- アプリで遅刻者に罰を与えない（責めるとかえって遅刻が増えてしまう）
- 位置情報を共有するだけでなく、情報を活用する
  - → 到着時間の予測、近くのスポット提案
- 前日に、位置情報をONにするよう通知してくれる（位置情報の設定し忘れ防止）

---

## 技術スタック

### フロントエンド
- **React Native** — iOS / Android クロスプラットフォーム対応

### バックエンド
- **Go** — APIサーバー
- **WebSocket** — フロントエンドとのリアルタイム双方向通信

### データベース
- **PostgreSQL** — メインDB
- **Neon** — サーバーレスPostgreSQLホスティング
- **PostGIS** — 位置情報（地理空間データ）の管理・クエリ

### 外部API
- **Google Maps API** — 地図表示・ルート計算・近辺スポット検索

### デプロイ
- **Render** または **Google Cloud Run** — バックエンドのホスティング

---

## 主要機能

### 待ち合わせ管理
- 待ち合わせの作成・参加（ルームコードやリンクで招待）
- 待ち合わせ時間・場所の設定

### リアルタイム位置情報共有
- 遅刻者の現在地をマップ上にリアルタイム表示
- 待っている側の位置情報も共有し、双方の合流をサポート
- WebSocketによる低遅延の位置情報更新

### 到着予定時間の表示
- Google Maps APIを用いたルート計算・ETA推定
- 余裕を持たせたバッファ付きで表示し、超過を防止

### 暇つぶしスポット提案
- 待機中のユーザーの現在地周辺のカフェ・施設などを提案
- Google Maps Places APIを活用

### 通知
- 前日に位置情報をONにするよう通知（設定し忘れ防止）
- 相手が出発したとき・近づいたときの通知

---

## セットアップ手順

### 必要環境

- Go 1.22+
- Node.js 20+
- React Native 開発環境（Expo または React Native CLI）
- PostgreSQL（ローカル） または Neon アカウント

### 1. リポジトリのクローン

```bash
git clone https://github.com/nitr0yukkuri/yakinikusoushoku_shisukai.git
cd yakinikusoushoku_shisukai
```

### 2. 環境変数の設定

ルートに `.env` を1つ置いて全変数をまとめて管理する。

```bash
cp .env.example .env
```

`.env` の内容を後述の「環境変数一覧」を参考に埋める。

> **注意:** `.env` は `.gitignore` に含まれているため、各自でローカルに作成すること。

### 3. バックエンドの起動

```bash
cd backend
go mod tidy

# DBマイグレーション
psql $DATABASE_URL -f migrations/0001_init.sql
psql $DATABASE_URL -f migrations/0002_friends.sql
psql $DATABASE_URL -f migrations/0003_meetups.sql

# サーバー起動
go run .
```

### 4. フロントエンドの起動

```bash
cd mobile
npm install
npx expo start
```

### 提出用ZIPについて

提出用ZIPはファイルサイズを抑えるため、`node_modules` フォルダを含めていません。
`node_modules` は依存パッケージから再生成できるため、ZIPを展開した後に以下を実行してください。

```bash
cd mobile
npm install
```

インストール完了後、以下のコマンドでアプリを起動できます。

```bash
npx expo start
```

---
### 5. なんかフロントエンドとかでバグったとき


```bash
cd mobile
 -c
```


## 環境変数一覧

すべての環境変数はルートの `.env` に記載する。  
バックエンド（Go）は `godotenv` で `../.env` を読み込み、フロントエンド（Expo）は起動時に自動で参照する。

| 変数名 | 使用箇所 | 説明 |
|---|---|---|
| `DATABASE_URL` | backend | NeonまたはローカルPostgreSQLの接続文字列 |
| `GOOGLE_MAPS_API_KEY` | backend | Google Maps / Places API キー（サーバー側） |
| `JWT_SECRET` | backend | 認証トークン署名用シークレット |
| `PORT` | backend | サーバーのリッスンポート（デフォルト: `8080`） |
| `ENV` | backend | 実行環境（`development` / `production`） |
| `EXPO_PUBLIC_API_URL` | frontend | バックエンドAPIのベースURL |
| `EXPO_PUBLIC_WS_URL` | frontend | WebSocketサーバーのURL |
| `EXPO_PUBLIC_GOOGLE_CLIENT_ID` | frontend | Google OAuth クライアントID |

---

## バックエンドAPI

`/health` と `/auth/google` 以外のユーザー向けAPIでは、原則として
`Authorization: Bearer <token>` を送信する。

### フレンド

- `GET /friends` — フレンド一覧
- `GET /friends/search?userId=...` — ID検索
- `POST /friends/requests` — 申請送信
- `GET /friends/requests` — 受信・送信中申請
- `PUT /friends/requests` — 承認・拒否・取消
- `DELETE /friends?userId=...` — フレンド削除
- `GET /friends/qr` — QRコードへ埋め込むデータ

### 待ち合わせ

- `GET /meetups` / `POST /meetups` — 一覧・作成
- `GET /meetups/{id}` / `PUT /meetups/{id}` / `DELETE /meetups/{id}` — 詳細・編集・中止
- `POST /meetups/join` — 招待コードで参加
- `PUT /meetups/{id}/members` — 招待の承認・辞退、メンバー削除
- `POST /meetups/{id}/eta` — Google Routes APIで自分のETAを計算・保存
- `GET /meetups/{id}/eta` — 参加者の最新ETA一覧

### WebSocket

1. `POST /ws/tickets` に `meetupId` を送り、60秒間有効な1回限りのチケットを取得する。
2. `GET /ws?ticket=...` へWebSocket接続する。
3. 承認済み参加者だけが接続でき、送信者のユーザーIDはサーバー側で確定する。

---

## ターゲット

- 友達同士でよく遊ぶ人
- 若者中心（大学1〜2年生くらい）
- よく遅刻をする／される人
- 外で遊ぶ人
